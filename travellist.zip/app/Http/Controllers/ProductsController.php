<?php

namespace App\Http\Controllers;


use App\Models\Products;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductsController extends Controller
{

    public function index()
    {
        $user_id = Auth::id();
        $cart = DB::table('cart_items')->where('user_id', $user_id)->get();
        $productInCart = [];
        foreach ($cart as $cartItem) {
            array_push($productInCart, $cartItem->product_id);
        }
        $all_products = Products::all();
        $total_product_in_cart = count($productInCart);

        foreach ($all_products as $eachProduct) {
            if (array_search($eachProduct->id, $productInCart) !== false) {
                $eachProduct->inCart = true;
            } else {
                $eachProduct->inCart = false;
            }
        }

        return view('welcome', ['products' => $all_products]);
    }

    public function addToCart(Request $request)
    {
        $quantity = ($request->quantity) ?  ($request->quantity) : 1;
        $product_id = $request->input('product_id');
        $user_id = Auth::id();

        DB::table('cart_items')->insert([
            'user_id' => $user_id,
            'product_id' => $product_id,
            'quantity' => $quantity,
        ]);

        return redirect()->back();
    }

    public function singleProductListing(Request $request, $id)
    {
        view('singleProduct');
    }

    public function searchProduct(Request $request)
    {
        $query = $request->get('searchQuery');
        if (empty($query)) {
            return 'empty-state';
        }
        if ($request->ajax()) {
            $products = Products::where('name', 'like', '%' . $query . '%')
                ->orWhere('desc', 'like', '%' . $query . '%')
                ->orWhere('price', 'like', '%' . $query . '%')->get();

            $output = '';
            if (count($products) > 0) {
                foreach ($products as $product) {
                    $output .= '<a href="/product/show/' . $product->id . '" class="box-border flex flex-col justify-center w-3/4 p-4 mx-auto bg-white border-2 border-white rounded-lg shadow align-center hover:border-blue-700 hover:border-2">
                    <div class="flex flex-col items-center gap-4 sm:flex-row">
                    <img src="/storage/' . $product->image . '" class="hidden w-36 md:block" alt="" />
                    <div class="flex flex-col justify-between">
                    <h2 class="mb-4 text-base font-semibold md:text-xl">' . $product->name . '</h2>
                    <div class="flex flex-col justify-between pr-3 mb-3 md:flex-row">
                    <h3 class="text-sm md:text-base">
                    ' . $product->desc . '
                    </h3>
                    <p class="pl-10 text-lg font-semibold">₹' . $product->price . '/-</p>
                    </div>
                    </div>
                    </div>
                    </a >';
                }
            } else {
                $output .= 'no-result';
            }

            return $output;
        }
    }
}
