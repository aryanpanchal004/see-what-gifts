<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function index()
    {
        $user_id = Auth::id();
        $orders = DB::select("Select * from orders where user_id =$user_id");
        $order_data = [];
        foreach ($orders as $order) {
            $order_id = $order->id;
            $orders_products = DB::select("select * from orders_products_details where order_id = $order_id");
            $order_product2 = [];

            foreach ($orders_products as $op) {
                $productId = $op->product_id;
                $productName = DB::select("select name from products where id = $productId");
                $op->name = $productName[0]->name;
                $order_product2[] = $op;
            }

            $shipping_data = DB::select("select * from shipping_data where order_id = $order_id");
            $temp = array([
                'order' => $order,
                'order_products' => $order_product2,
                'shipping_data' => $shipping_data
            ]);
            $order_data[] = $temp;
        }

        // dd($order_data);
        return view('orders', ['order_data' => $order_data]);
    }
}
