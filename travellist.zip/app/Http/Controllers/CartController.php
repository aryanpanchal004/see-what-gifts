<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    public function index()
    {
        $user_id = Auth::id();
        $productsInCart = DB::table('cart_items')->where('user_id', $user_id)->get();
        $products = [];
        $totalAmount = 0;
        foreach ($productsInCart as $product) {
            $product_id = $product->product_id;
            $realProduct = DB::table('products')->where('id', $product_id)->first();
            $realProduct->quantity = $product->quantity;
            $totalAmount += $realProduct->price;
            array_push($products, $realProduct);
        }


        return view('cart', ['products' => $products, 'total' => $totalAmount, 'productsInCart' => $productsInCart, 'user_id' => $user_id]);
    }

    public function deleteProduct($id)
    {
        DB::table('cart_items')->where('product_id', $id)->delete();
        return back();
    }
}
