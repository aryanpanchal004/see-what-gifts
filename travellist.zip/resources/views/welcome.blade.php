<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="{{ asset('dist/output.css') }}" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    {{-- flowbite css --}}
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.3/flowbite.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM="
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tw-elements/dist/css/index.min.css" />
</head>

<body>
    @include('partials.header')

    {{-- <section class="text-gray-600 body-font"> --}}
        <div class="container flex flex-wrap py-4 mx-auto">
          <div class="flex flex-wrap -m-1 md:-m-2">
            <div class="flex flex-wrap w-1/2">
              <div class="w-1/2 p-1 md:p-2">
                <img alt="gallery" class="block object-cover object-center w-full h-full" src="images/gallery/gallery-1.jpg">
              </div>
              <div class="w-1/2 p-1 md:p-2">
                <img alt="gallery" class="block object-cover object-center w-full h-full" src="images/gallery/gallery-2.jpg">
              </div>
              <div class="w-full p-1 md:p-2">
                <img alt="gallery" class="block object-cover object-center w-full h-full" src="images/gallery/gallery-3.jpg">
              </div>
            </div>
            <div class="flex flex-wrap w-1/2">
              <div class="w-full p-1 md:p-2">
                <img alt="gallery" class="block object-cover object-center w-full h-full" src="images/gallery/gallery-4.jpg">
              </div>
              <div class="w-1/2 p-1 md:p-2">
                <img alt="gallery" class="block object-cover object-center w-full h-full" src="images/gallery/gallery-5.jpg">
              </div>
              <div class="w-1/2 p-1 md:p-2">
                <img alt="gallery" class="block object-cover object-center w-full h-full" src="images/gallery/gallery-6.jpg">
              </div>
            </div>
          </div>
        </div>
      </section>

      {{-- products section --}}      
      <section class="text-gray-600 body-font">
        <div class="container px-5 py-4 mx-auto">
          <h3 class="pb-4 text-3xl text-black">Products</h3>
          <div class="flex flex-wrap -m-4">
            @foreach ($products as $product)
            <div class="w-full p-4 lg:w-1/4 md:w-1/2">
              <a href="{{ 'product/show/'.$product->id }}" class="relative block overflow-hidden rounded">
                <img alt="ecommerce" class="block object-cover object-center w-full h-full" src="{{ asset('storage/' . $product->image) }}">
              </a>
              <div class="mt-4">
                {{-- <h3 class="mb-1 text-xs tracking-widest text-gray-500 title-font">CATEGORY</h3> --}}
                <div class="flex justify-between">
                  <a href="{{ 'product/show/'.$product->id }}"">  
                    <h2 class="text-lg font-medium text-gray-900 title-font">{{ $product->name }}</h2>
                  </a>
                  @if($product->inCart == true)                    
                  <form method="GET" action="/cart" >
                    <button class="px-4 py-2 text-white rounded-md bg-sky-500 hover:bg-sky-600">Checkout</button>
                  </form>
                  @else 
                  <form method="POST" action="/addToCart" >
                    @csrf
                    @method('post')
                    <input type="hidden"  name="product_id" value="{{ $product->id }}">
                    <button class="px-4 py-2 text-white rounded-md bg-sky-500 hover:bg-sky-600">Add to cart</button>
                  </form>
                  @endif 
                </div>
                <p class="mt-1">₹{{ $product->price }}.00</p>
              </div>
            </div>
            @endforeach
          </div>
        </div>
      </section>

      {{-- dynamic search --}}
      <div id="search-output" class="absolute left-0 right-0 top-20"></div>


      @include('partials.footer')

  
<script src="javascript/navbar_logic.js"></script> 
<script src="javascript/search_logic.js"></script> 
</body>

</html>
