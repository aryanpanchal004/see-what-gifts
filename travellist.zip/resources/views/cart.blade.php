<!DOCTYPE html>
<html lang="en">
<head>
    <title>Winistar | Cart</title>
    <x-includeFile />
</head>
<body>
    
{{-- <main class="p-5">
    <div class="container mx-auto lg:w-2/3 xl:w-2/3">
      <h1 class="mb-6 text-2xl font-bold md:text-3xl">Your Cart Items</h1>

      <div class="p-4 bg-white rounded-lg shadow">
        <!-- Product Items -->
        <div>
          
          @if(count($products) == 0)
            <h1 class="text-lg font-semibold text-center md:text-2xl">No Product Found inside Cart!</h1>
          
          @else
          @foreach ($products as $product)
          <!-- Product Item -->
          <div class="flex flex-col items-center gap-4 sm:flex-row">
            <img src="{{ asset("/storage/$product->image")  }}" class="w-36" alt="" />
            <div class="flex flex-col justify-between">
              <h2 class="mb-4 text-xl font-semibold">Toilet Cleaner</h2>
              <div class="flex justify-between mb-3">
                <h3>
                  {{ $product->desc }}
                </h3>
                <span class="text-lg font-semibold">₹{{ $product->price }}/-</span>
              </div>
              <div class="flex items-center justify-between">
                <label for="qty" class="flex items-center">
                  Qty:
                  <input
                    type="number"
                    name="quantity"
                    id="qty"
                    class="py-1 ml-3 border-gray-700 text-center border rounded-lg"
                    value={{ $product->quantity }}
                  >
                </label>
                <form method="POST" action="/cart/delete/{{ $product->id }}">
                  @csrf
                  @method('DELETE')
                  <button class="text-purple-600 hover:text-purple-500"
                  >Remove</button>
                </form>
              </div>
            </div>
          </div>
          <!--/ Product Item -->
          <hr class="my-5" />
          @endforeach
          <div class="pt-4 border-t border-gray-300">
            <div class="flex justify-between">
              <span class="font-semibold">Subtotal</span>
              <span class="text-xl">₹{{ $total }}/-</span>
            </div>
            <p class="mb-6 text-gray-500">
              Shipping and taxes calculated at checkout.
            </p>
  
            <form method="POST" action="/address">
              @csrf
              @method('POST')
              <input type="text" value="{{ $user_id }}" name="user_id" class="hidden">
              <button type="submit" class="w-full py-3 text-lg text-white bg-purple-600 hover:bg-purple-700">
                Proceed to Checkout
              </button>
            </form>
            </div>
          @endif
        </div>
        <!--/ Product Items -->

      </div>
    </div>
</main> --}}

      <div class="flex h-full flex-col bg-white shadow-xl">
        <div class="flex-1 overflow-y-auto py-6 px-4 sm:px-6">
          <div class="flex items-start justify-between">
            <h2 class="text-lg font-medium text-gray-900" id="slide-over-title">Shopping cart</h2>
            <div class="ml-3 flex h-7 items-center">
              <button type="button" class="-m-2 p-2 text-gray-400 hover:text-gray-500">
              </button>
            </div>
          </div>

          <div class="mt-8">
            <div class="flow-root">
              <ul role="list" class="-my-6 divide-y divide-gray-200">
            @if(count($products) == 0)
              <h1 class="text-lg font-semibold text-center md:text-2xl">No Product Found inside Cart!</h1>
            @else
              @foreach ($products as $product)
                <li class="flex py-6">
                  <div class="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                    <img src="{{ asset("/storage/$product->image")  }}" alt="Salmon orange fabric pouch with match zipper, gray zipper pull, and adjustable hip belt." class="h-full w-full object-cover object-center">
                  </div>

                  <div class="ml-4 flex flex-1 flex-col">
                    <div>
                      <div class="flex justify-between text-base font-medium text-gray-900">
                        <h3>
                          <a href="#">{{ $product->name }}</a>
                        </h3>
                        <p class="ml-4">₹{{ $product->price }}.00</p>
                      </div>
                      {{-- <p class="mt-1 text-sm text-gray-500">Salmon</p> --}}
                    </div>
                    <div class="flex flex-1 items-end justify-between text-sm">
                      {{-- <p class="text-gray-500">Qty 1</p> --}}
                      <label for="qty" class="flex items-center">
                        Qty:
                        <input
                          type="number"
                          name="quantity"
                          id="qty"
                          class="py-1 ml-3 border-gray-700 text-center border rounded-lg w-16"
                          value={{ $product->quantity }} 
                        >
                      </label>
                      <div class="flex">
                        <form method="POST" action="/cart/delete/{{ $product->id }}">
                            @csrf
                            @method('DELETE')
                          <button class="font-medium text-indigo-600 hover:text-indigo-500">Remove</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </li>
              @endforeach
            @endif
              </ul>
            </div>
          </div>
        </div>

        @if(count($products) > 0)  
        <div class="border-t border-gray-200 py-6 px-4 sm:px-6">
          <div class="flex justify-between text-base font-medium text-gray-900">
            <p>Subtotal</p>
            <p>₹{{ $total }}.00/-</p>
          </div>
          <p class="mt-0.5 text-sm text-gray-500">Shipping and taxes calculated at checkout.</p>
          <div class="mt-6">
            <form method="POST" action="/address">
              @csrf
              @method('POST')
              <input type="text" value="{{ $user_id }}" name="user_id" class="hidden">
              <button href="#" class="flex items-center w-full justify-center rounded-md border border-transparent bg-indigo-600 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-indigo-700">Checkout</button>
            </form>
          </div>
          <div class="mt-6 flex justify-center text-center text-sm text-gray-500">
            <p>
              or
              <a href="{{ route('welcome') }}" type="button" class="font-medium text-indigo-600 hover:text-indigo-500">
                Continue Shopping
                <span aria-hidden="true"> &rarr;</span>
              </a>
            </p>
          </div>
        </div>
        @endif
      </div>
    </div>
    
  </body>
  </html>