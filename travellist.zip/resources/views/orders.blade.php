<!DOCTYPE html>
<html lang="en">
<head>
    <title>Winistar | Cart</title>
    <x-includeFile />
</head>
<body>
    
<main class="p-5">
    
    <div class="container mx-auto lg:w-2/3 xl:w-2/3">
      <h1 class="mb-6 text-2xl font-bold md:text-3xl">My Orders</h1>

      <div class="p-4 bg-white rounded-lg shadow">
        <!-- Product Items -->
        <div>
          {{-- <!-- Product Item -->
          <div class="flex flex-col items-center gap-4 sm:flex-row">
            <img src="{{ asset("/storage/products/p1.jpg")  }}" class="w-36" alt="" />
            <div class="flex flex-col justify-between">
              <h2 class="mb-4 text-xl font-semibold">Toilet Cleaner</h2>
              <div class="flex justify-between mb-3">
                <h3>
                   Something
                </h3>
                <span class="text-lg font-semibold">₹500/-</span>
              </div>
            </div>
          </div> --}}
          @if(count($order_data) == 0)
                
          @else  
                @foreach ($order_data as $orders)  
                <table class="table-auto text-lg border-2 border-black mt-10">
                <thead>
                    <tr class="border-2 border-black">
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th> 
                        <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        {{-- @php
                            $grandTotal = 0;
                            @endphp --}}
                            @foreach ($orders[0]['order_products'] as $order)
                         
                            <tr class="border-2 border-black">
                                <td class="px-4 py-2">{{ $order->name }}</td>
                                <td class="px-4 py-2">₹{{ $order->price }}/-</td>
                                <td class="px-4 py-2">{{ $order->quantity }}</td>
                                <td class="px-8 py-2">₹{{ ($order->quantity)*($order->price) }}/-</td>
                                {{-- @php
                                    $grandTotal += ($product->quantity)*($product->price);
                                    @endphp --}}
                                </tr>
                                @endforeach
                                <tr class="border-2 border-black">
                    <td colspan="3" class="px-4 py-2 font-bold">Grand Total</td>
                    {{-- <td class="px-8 py-2">₹{{ $grandTotal }}/-</td> --}}
                    </tr>
                </tbody>
            </table>
            @endforeach
        @endif
        <!--/ Product Items -->
        
    </div>
</div>
</main>
</body>
</html>