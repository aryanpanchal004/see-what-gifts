<?php

use App\Models\Products;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProductsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes(['verify' => true]);

Route::get('/', [ProductsController::class, 'index'])->name('welcome');

Route::get('/products/search', [ProductsController::class, 'searchProduct'])->name('search-products');


Route::get('/dashboard', function () {
    return view('welcome', ['products' => Products::all()]);
})->name('dashboard')->middleware('verified');

// return cart page
Route::get('/cart', [CartController::class, 'index'])->name('cart')->middleware('auth');

// Add to cart
Route::post('/addToCart', [ProductsController::class, 'addToCart'])->name('addToCart')->middleware('auth');

// delete product from cart
Route::delete('/cart/delete/{id}', [CartController::class, 'deleteProduct'])->name('removeFromCart')->middleware('auth');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// payment Controller 
Route::post('/checkout/payonline', [PaymentController::class, 'checkout'])->name('checkout.online')->middleware('auth');;

// success cancel
Route::get('/checkout/cancel', [PaymentController::class, 'cancel'])->name('checkout.cancel')->middleware('auth');;

// success checkout
Route::get('/checkout/success', [PaymentController::class, 'success'])->name('checkout.success')->middleware('auth');;

Route::get('/checkout/success', [PaymentController::class, 'success'])->name('checkout.success')->middleware('auth');;

Route::post('/webhook', [PaymentController::class, 'webhook'])->name('checkout.webhook');

// checkout address  form
Route::post('/address', [PaymentController::class, 'address'])->name('checkout.address')->middleware('auth');;

// show all orders in one page
Route::get('/orders/show', [OrderController::class, 'index'])->name('showOrders')->middleware('auth');;

// cash on delivery handling
Route::post("/cashOnDelivery", [PaymentController::class, 'cod'])->name('checkout.cod')->middleware('auth');;

// show single product
Route::get('/product/show/{id}', function ($id) {
    $products = Products::all();
    $product = $products->find($id);

    $user_id = Auth::id();
    $cart = DB::table('cart_items')->where('user_id', $user_id)->get();
    if (count($cart) == 0) {
        $product->inCart = false;
    } else if ($cart[0]->product_id == $id) {
        $product->inCart = true;
    } else {
        $product->inCart = false;
    }

    return view('singleProduct', ['product' => $product]);
})->where(array('id' => '[0-9]+'))->name("showProductListing");

require __DIR__ . '/auth.php';

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
